package com.example.cheatbutton

import android.content.Context

object Cheats {
    // One per line:  Label=CODE   (edit these in the app)
    const val DEFAULTS = "Health+Armor+Money=HESOYAM\n" +
        "Clear wanted=ASNAEB\n" +
        "Weapons 1=LXGIWYL\n" +
        "Jetpack=ROCKETMAN\n" +
        "Rhino tank=AIWPRTON\n" +
        "Hydra=JUMPJET"

    private fun prefs(c: Context) = c.getSharedPreferences("cheats", Context.MODE_PRIVATE)

    fun getText(c: Context): String = prefs(c).getString("list", DEFAULTS) ?: DEFAULTS
    fun setText(c: Context, t: String) = prefs(c).edit().putString("list", t).apply()

    fun getDelay(c: Context): Int = prefs(c).getInt("delay", 0)
    fun setDelay(c: Context, ms: Int) = prefs(c).edit().putInt("delay", ms).apply()

    fun parse(c: Context): List<Pair<String, String>> =
        getText(c).lines().mapNotNull { line ->
            val i = line.lastIndexOf('=')
            if (i <= 0) null else line.substring(0, i).trim() to line.substring(i + 1).trim()
        }.filter { it.second.isNotEmpty() }
}
