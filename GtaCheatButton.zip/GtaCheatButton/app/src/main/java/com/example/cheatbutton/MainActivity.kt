package com.example.cheatbutton

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var list: EditText
    private lateinit var delay: EditText

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        runCatching { Shizuku.addRequestPermissionResultListener(permListener) }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; setOnClickListener { onClick() }
        }.also { col.addView(it) }

        status = TextView(this).apply { textSize = 15f }
        col.addView(status)

        btn("1. Allow draw-over-apps") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        btn("2. Grant Shizuku access") {
            try {
                if (!Shizuku.pingBinder()) {
                    Toast.makeText(this, "Start Shizuku first (see its app)", Toast.LENGTH_LONG).show()
                } else {
                    Shizuku.requestPermission(1)
                }
            } catch (e: Throwable) {
                Toast.makeText(this, "Shizuku not available", Toast.LENGTH_LONG).show()
            }
        }

        col.addView(TextView(this).apply {
            text = "\nCheats (one per line, Label=CODE):"
        })
        list = EditText(this).apply {
            setText(Cheats.getText(this@MainActivity))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            minLines = 6
        }
        col.addView(list)

        col.addView(TextView(this).apply {
            text = "Delay between letters in ms (0 = fastest; raise if the game misses letters):"
        })
        delay = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(Cheats.getDelay(this@MainActivity).toString())
        }
        col.addView(delay)

        btn("Save") {
            Cheats.setText(this, list.text.toString())
            Cheats.setDelay(this, delay.text.toString().toIntOrNull() ?: 0)
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }
        btn("Start floating button") {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
            }
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Allow draw-over-apps first", Toast.LENGTH_LONG).show()
            } else {
                startForegroundService(Intent(this, OverlayService::class.java))
            }
        }
        btn("Stop floating button") { stopService(Intent(this, OverlayService::class.java)) }

        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val overlay = Settings.canDrawOverlays(this)
        val running = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        val ok = Shell.ready()
        status.text = "Overlay permission: ${if (overlay) "OK" else "missing"}\n" +
            "Shizuku running: ${if (running) "yes" else "no"}\n" +
            "Shizuku access: ${if (ok) "granted" else "not granted"}"
    }

    override fun onDestroy() {
        runCatching { Shizuku.removeRequestPermissionResultListener(permListener) }
        super.onDestroy()
    }
}
