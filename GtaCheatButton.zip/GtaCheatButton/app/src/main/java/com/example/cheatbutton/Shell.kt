package com.example.cheatbutton

import android.content.pm.PackageManager
import android.view.KeyEvent
import rikka.shizuku.Shizuku
import java.util.Locale

object Shell {

    fun ready(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    /** Sends [code] one key at a time (A-Z, 0-9) as real key events. */
    fun sendKeys(code: String, delayMs: Int) {
        val keys = code.uppercase().mapNotNull { ch ->
            val k = KeyEvent.keyCodeFromString("KEYCODE_$ch")
            if (k == KeyEvent.KEYCODE_UNKNOWN) null else k
        }
        if (keys.isEmpty()) return

        val cmd = if (delayMs <= 0) {
            "input keyevent ${keys.joinToString(" ")}"
        } else {
            val gap = String.format(Locale.US, "%.3f", delayMs / 1000.0)
            keys.joinToString("; sleep $gap; ") { "input keyevent $it" }
        }
        run(cmd)
    }

    // Shizuku.newProcess is private in API 13+, so call it via reflection.
    private fun run(cmd: String) {
        Thread {
            try {
                val m = Shizuku::class.java.getDeclaredMethod(
                    "newProcess",
                    Array<String>::class.java,
                    Array<String>::class.java,
                    String::class.java
                )
                m.isAccessible = true
                val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
                p.waitFor()
            } catch (_: Throwable) {
            }
        }.start()
    }
}
