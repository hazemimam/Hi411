package com.example.cheatbutton

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import kotlin.math.abs

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var root: LinearLayout? = null
    private var panel: LinearLayout? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildOverlay()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("cheat", "Cheat button", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "cheat")
            .setContentTitle("Cheat button is running")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun roundBg(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun buildOverlay() {
        val container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val main = Button(this).apply {
            text = "GTA"
            textSize = 12f
            setTextColor(Color.WHITE)
            background = roundBg(0xCC222222.toInt(), 24)
            minWidth = 0; minHeight = 0
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }

        val panelView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            background = roundBg(0xE6222222.toInt(), 12)
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        val scroll = ScrollView(this).apply { addView(panelView) }

        container.addView(main)
        container.addView(
            scroll,
            LinearLayout.LayoutParams(dp(200), LinearLayout.LayoutParams.WRAP_CONTENT)
        )

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            // NOT_FOCUSABLE keeps the game focused so key events reach it.
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = dp(150)
        }

        // Drag to move, tap to open/close.
        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f; var moved = false
        main.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = startX + dx
                        lp.y = startY + dy
                        wm.updateViewLayout(container, lp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) togglePanel(panelView)
            }
            true
        }

        root = container
        panel = panelView
        wm.addView(container, lp)
    }

    private fun togglePanel(p: LinearLayout) {
        if (p.visibility == View.VISIBLE) {
            p.visibility = View.GONE
            return
        }
        p.removeAllViews()
        val delay = Cheats.getDelay(this)
        for ((label, code) in Cheats.parse(this)) {
            p.addView(Button(this).apply {
                text = label
                isAllCaps = false
                textSize = 13f
                setOnClickListener {
                    if (Shell.ready()) {
                        Shell.sendKeys(code, delay)
                        Toast.makeText(context, "Sent $label", Toast.LENGTH_SHORT).show()
                        p.visibility = View.GONE
                    } else {
                        Toast.makeText(context, "Shizuku not running / not allowed", Toast.LENGTH_LONG).show()
                    }
                }
            })
        }
        p.addView(Button(this).apply {
            text = "Close floating button"
            isAllCaps = false
            textSize = 12f
            setOnClickListener { stopSelf() }
        })
        p.visibility = View.VISIBLE
    }

    override fun onDestroy() {
        root?.let { runCatching { wm.removeView(it) } }
        root = null
        super.onDestroy()
    }
}
