# Cheat Button (Shizuku)

Floating button that types cheat codes (e.g. for single-player GTA) letter by letter
as real key events, using Shizuku for shell-level input.

## Build
- Android Studio: File > Open this folder, let it sync, Build > Build APK(s).
- Or push to GitHub: the included workflow builds app-debug.apk (Actions > artifacts).

## Use
1. Install Shizuku and start it (wireless debugging, no PC needed on Android 11+).
2. Open Cheat Button: allow draw-over-apps, grant Shizuku access, edit cheats, Start.
3. Open the game, tap the floating GTA button, pick a cheat.

If letters get missed, raise the delay (try 30-80 ms).
